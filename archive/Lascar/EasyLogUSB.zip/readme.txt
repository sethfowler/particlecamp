
Readme File

Windows(TM) control software for EL-USB data loggers

Issue 6.60 - 03/06/2013

(c) Lascar Electronics Ltd., 2004-2013. All rights reserved.


---------------------
Hardware Requirements
---------------------
- PC running Windows XP, Vista and Windows 7 32-bit and 64-bit versions
- CD-ROM/DVD drive
- Free USB port


---------------------------------------------------------
EL-WIN-USB   Configuration Software and Driver Installation 
---------------------------------------------------------

The following notes cover the recommended installation procedure for software & hardware drivers.  

1. You must have Administrator rights to install this software.

2. Insert the EL-WIN-USB Mini-CD into the CD/DVD drive - DO NOT REMOVE IT until you reach the end of this procedure.

3. The CD should simply auto-run. If the CD does not start automatically click "start", "Run" and type D:\setup.exe then click [OK] (where D:\ denotes the CD/DVD drive letter).

4. Step through the wizard until the installation is complete. Once the application has installed the EasyLog USB Device Driver Installer will automatically run, select "Install"

5. Ensure that the battery is in the EL-USB module.

6. Insert the EL-USB module into a free USB port on your computer.  The computer will automatically detect the presence of the EL-USB module and install the hardware driver. 

7. Double-click the EasyLog USB icon on the Desktop to launch the control software.  You will be presented with three options on the Main Screen.

8. Remove the CD from the drive. 

---------------------------------------------------------
Driver Installation Troubleshooting
---------------------------------------------------------

The EasyLog USB Device Driver Installer will run automatically when installing the application software. To run the EasyLog USB Device Driver Installer separately it can be found on the CD or once the application has been installed in the "C:\Program Files\EasyLog USB\" folder on 32-bit operating systems and "C:\Program Files (x86)\EasyLog USB\" folder on 64-bit operating systems.

Note:- This version of the software will not work with previous versions of the driver.
